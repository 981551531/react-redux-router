import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux'   ;
import * as userinfoActions from '../../actions/userInfo'
import { Link } from 'react-router-dom'
import './style.css'

class Home extends React.Component {
    render() {
        return (
            <div className='kk'>
                首页 {this.props.userDate.city}
                <hr />
                <Link to="/re">跳转到Reudx页面</Link>
            </div>
        )
    }

    componentDidMount() {
        console.log("home",this.props.userDate.city)
    }


}

function mapStateToProps(state) {
    return {
        userDate: state.userDatettt
    }
}

function mapDispatchToProps(dispatch) {
    return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);